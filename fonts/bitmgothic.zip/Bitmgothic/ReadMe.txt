:::ABOUT BITMGOTHIC:::

BitmGothic is a free font created by Nomi in the summer of 2012.

With this font, you can:
1. Use it freely either for your personal letters or for your commercial products.
2. Credit my name if you feel generous and very nice to do so.
3. Show me how you used this font. 

You can do pretty much anything with this font but please don’t sell it without my permission.

Hope you enjoy this new addition to your font collection :-)
Cheers.

—-
Nomi 
http://www.thenomi.org
@the_nomi